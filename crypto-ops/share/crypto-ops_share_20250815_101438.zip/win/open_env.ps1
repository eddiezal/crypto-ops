Param()
notepad .\.env
