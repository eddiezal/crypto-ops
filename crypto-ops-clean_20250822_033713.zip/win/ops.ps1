#Requires -Version 5.1
Set-StrictMode -Version Latest

# ---------------- Module configuration ----------------
$script:CryptoOps = @{
  DefaultService = 'cryptoops-planner'
  DefaultRegion  = 'us-central1'
}

# ---------------- Context & auth ----------------
function Get-Context {
  [CmdletBinding()]
  param(
    [string]$Service = $script:CryptoOps.DefaultService,
    [string]$Region  = $script:CryptoOps.DefaultRegion
  )
  $Project = (gcloud config get-value core/project)
  if (-not $Project) { throw "gcloud core/project is not set. Run: gcloud config set project <PROJECT_ID>" }
  $Bucket  = "cryptoops-state-$Project"
  $SA      = "cryptoops-run@$Project.iam.gserviceaccount.com"
  $Url     = (gcloud run services describe $Service --region $Region --format 'value(status.url)')
  [pscustomobject]@{ Project=$Project; Region=$Region; Service=$Service; Bucket=$Bucket; SA=$SA; Url=$Url }
}

function Get-RunUrl {
  [CmdletBinding()]
  param(
    [string]$Service = $script:CryptoOps.DefaultService,
    [string]$Region  = $script:CryptoOps.DefaultRegion
  )
  gcloud run services describe $Service --region=$Region --format='value(status.url)'
}

function Get-RunToken {
  <#
  .SYNOPSIS
    Mint an ID token for the private Cloud Run service using the runtime service account.
  #>
  [CmdletBinding()]
  param(
    [string]$Service = $script:CryptoOps.DefaultService,
    [string]$Region  = $script:CryptoOps.DefaultRegion
  )
  $ctx = Get-Context -Service $Service -Region $Region
  $url = $ctx.Url
  $sa  = $ctx.SA
  $token = gcloud auth print-identity-token --audiences="$url" --impersonate-service-account="$sa" 2>$null
  if (-not $token) {
    throw "Failed to mint ID token via SA $sa for $url. Ensure roles/run.invoker on service and roles/iam.serviceAccountTokenCreator + roles/iam.serviceAccountUser on the SA."
  }
  return $token
}

# ---------------- Deploy + runtime helpers ----------------
function Deploy-CryptoOps {
  [CmdletBinding()]
  param(
    [string]$SourcePath = (Get-Location).Path,
    [string]$Service    = $script:CryptoOps.DefaultService,
    [string]$Region     = $script:CryptoOps.DefaultRegion,
    [switch]$EnableDebug
  )
  $ctx = Get-Context -Service $Service -Region $Region
  $env = @(
    "TRADING_MODE=paper",
    "COINBASE_ENV=sandbox",
    "STATE_BUCKET=$($ctx.Bucket)",
    "LEDGER_DB=/tmp/ledger.db",
    "LEDGER_DB_GCS=gs://$($ctx.Bucket)/data/ledger.db",
    "ENABLE_DEBUG_ENDPOINTS={0}" -f ($(if($EnableDebug){1}else{0}))
  ) -join ','
  gcloud run deploy $Service `
    --source "$SourcePath" `
    --region "$Region" `
    --service-account "$($ctx.SA)" `
    --no-allow-unauthenticated `
    --set-env-vars "$env" | Out-Host
  Write-Host "Service URL: $(Get-RunUrl -Service $Service -Region $Region)"
}

function Prices-Append {
  [CmdletBinding()]
  param(
    [switch]$Commit,
    [switch]$Refresh,
    [string]$Service = $script:CryptoOps.DefaultService,
    [string]$Region  = $script:CryptoOps.DefaultRegion
  )
  $url = Get-RunUrl -Service $Service -Region $Region
  $tok = Get-RunToken -Service $Service -Region $Region
  $qs = @()
  $qs += "commit={0}" -f ($(if($Commit){1}else{0}))
  if ($Refresh) { $qs += "refresh=1" }
  $endpoint = "$url/prices_append?$(($qs -join '&'))"
  Invoke-RestMethod -Method GET -Uri $endpoint -Headers @{ Authorization = "Bearer $tok" }
}

function Create-SchedulerJobs {
  [CmdletBinding()]
  param(
    [string]$Service  = $script:CryptoOps.DefaultService,
    [string]$Region   = $script:CryptoOps.DefaultRegion,
    [string]$TimeZone = 'Etc/UTC'
  )
  $ctx = Get-Context -Service $Service -Region $Region
  $url = $ctx.Url
  $sa  = $ctx.SA

  function _Upsert([string]$name,[string]$uri,[string]$schedule) {
    gcloud scheduler jobs describe $name --location=$Region *> $null
    if ($LASTEXITCODE -ne 0) {
      gcloud scheduler jobs create http $name `
        --location=$Region --schedule="$schedule" --time-zone="$TimeZone" `
        --http-method=GET --uri="$uri" `
        --oidc-service-account-email="$sa" --oidc-token-audience="$url" | Out-Host
    } else {
      gcloud scheduler jobs update http $name `
        --location=$Region --schedule="$schedule" --time-zone="$TimeZone" `
        --http-method=GET --uri="$uri" `
        --oidc-service-account-email="$sa" --oidc-token-audience="$url" | Out-Host
    }
  }

  _Upsert 'price-append-5m' "$url/prices_append?commit=1&refresh=1" '1-59/5 * * * *'
  _Upsert 'apply-paper-15m' "$url/apply_paper?refresh=1&commit=1" '*/15 * * * *'
  _Upsert 'snapshot-daily'  "$url/snapshot_now?commit=1" '0 0 * * *'
  Write-Host "Scheduler jobs upserted in $Region for $Service."
}
Set-Alias -Name New-SchedulerJobs -Value Create-SchedulerJobs -Scope Script -Force

# ---------------- Monitoring primitive ----------------
function Get-MonTimeSeries {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Project,
    [Parameter(Mandatory)][string]$Filter,
    [Parameter(Mandatory)][string]$StartTime,
    [Parameter(Mandatory)][string]$EndTime,
    [hashtable]$Aggregation
  )
  $access = gcloud auth print-access-token
  $qs = @(
    "interval.startTime=$([uri]::EscapeDataString($StartTime))",
    "interval.endTime=$([uri]::EscapeDataString($EndTime))",
    "filter=$([uri]::EscapeDataString($Filter))"
  )
  if ($Aggregation) {
    if ($Aggregation.alignmentPeriod)    { $qs += "aggregation.alignmentPeriod=$($Aggregation.alignmentPeriod)" }
    if ($Aggregation.perSeriesAligner)   { $qs += "aggregation.perSeriesAligner=$($Aggregation.perSeriesAligner)" }
    if ($Aggregation.crossSeriesReducer) { $qs += "aggregation.crossSeriesReducer=$($Aggregation.crossSeriesReducer)" }
    if ($Aggregation.groupByFields) {
      foreach ($g in $Aggregation.groupByFields) { $qs += "aggregation.groupByFields=$([uri]::EscapeDataString($g))" }
    }
  }
  $uri = "https://monitoring.googleapis.com/v3/projects/$Project/timeSeries?$(($qs -join '&'))"
  Invoke-RestMethod -Method GET -Uri $uri -Headers @{ Authorization = "Bearer $access" }
}

# ---------------- p95 latency ----------------
function Get-CloudRunP95 {
  [CmdletBinding()]
  param(
    [string]$Project = (gcloud config get-value core/project),
    [string]$Service = $script:CryptoOps.DefaultService,
    [int]$WindowMinutes = 5
  )
  $end   = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  $start = (Get-Date).ToUniversalTime().AddMinutes(-$WindowMinutes).ToString('yyyy-MM-ddTHH:mm:ssZ')
  $filter = 'metric.type="run.googleapis.com/request_latencies" AND resource.type="cloud_run_revision" AND resource.labels.service_name="' + $Service + '"'
  $resp = Get-MonTimeSeries -Project $Project -Filter $filter -StartTime $start -EndTime $end -Aggregation @{
    alignmentPeriod='60s'; perSeriesAligner='ALIGN_PERCENTILE_95'; crossSeriesReducer='REDUCE_MAX'; groupByFields=@('resource.labels.service_name')
  }
  $rows = @()
  if ($resp -and $resp.timeSeries) {
    $ts = $resp.timeSeries; if ($ts -isnot [System.Array]) { $ts=@($ts) }
    foreach ($pt in $ts[0].points) {
      $v = $pt.value.doubleValue; if ($null -eq $v) { $v = [double]$pt.value.int64Value }
      $rows += [pscustomobject]@{
        minute_end_utc = [DateTimeOffset]::Parse($pt.interval.endTime).UtcDateTime
        p95_ms         = [math]::Round([double]$v, 0)
      }
    }
  }
  $sorted = $rows | Sort-Object minute_end_utc
  if ($sorted) { $sorted } else { @() }
}

# ---------------- 5xx ratio (robust) ----------------
function Get-CloudRun5xxRatio {
  [CmdletBinding()]
  param(
    [string]$Project = (gcloud config get-value core/project),
    [string]$Service = $script:CryptoOps.DefaultService,
    [int]$WindowMinutes = 5
  )
  $end   = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
  $start = (Get-Date).ToUniversalTime().AddMinutes(-$WindowMinutes).ToString('yyyy-MM-ddTHH:mm:ssZ')

  $agg = @{ alignmentPeriod='60s'; perSeriesAligner='ALIGN_DELTA'; crossSeriesReducer='REDUCE_SUM'; groupByFields=@('resource.labels.service_name') }
  $base  = ('metric.type="run.googleapis.com/request_count" AND resource.type="cloud_run_revision" AND resource.labels.service_name="{0}"' -f $Service)
  $fltNum = $base + ' AND metric.labels.response_code_class="5xx"'
  $fltDen = $base

  $respNum = Get-MonTimeSeries -Project $Project -Filter $fltNum -StartTime $start -EndTime $end -Aggregation $agg
  $respDen = Get-MonTimeSeries -Project $Project -Filter $fltDen -StartTime $start -EndTime $end -Aggregation $agg

  function _Vals($resp) {
    $list = New-Object 'System.Collections.Generic.List[double]'
    if ($null -eq $resp -or -not ($resp.PSObject.Properties.Name -contains 'timeSeries')) { return $list.ToArray() }
    $ts = $resp.timeSeries; if ($ts -isnot [System.Array]) { $ts=@($ts) }
    if ($ts.Length -lt 1) { return $list.ToArray() }
    $series = $ts[0]
    if (-not ($series.PSObject.Properties.Name -contains 'points') -or -not $series.points) { return $list.ToArray() }
    foreach ($p in ($series.points | Sort-Object { [DateTimeOffset]::Parse($_.interval.endTime) })) {
      $v = $null
      if ($p.value) {
        if ($p.value.doubleValue -ne $null) { $v = [double]$p.value.doubleValue }
        elseif ($p.value.int64Value -ne $null) { $v = [double]$p.value.int64Value }
      }
      if ($v -ne $null) { [void]$list.Add($v) }
    }
    return $list.ToArray()
  }

  $num = _Vals $respNum
  $den = _Vals $respDen

  $lastNum   = if ($num.Length -gt 0) { $num[$num.Length-1] } else { 0.0 }
  $lastDen   = if ($den.Length -gt 0) { $den[$den.Length-1] } else { 0.0 }
  $lastRatio = if ($lastDen -gt 0) { [math]::Round($lastNum / $lastDen, 4) } else { $null }

  $sumNum = ($num | Measure-Object -Sum).Sum; if ($null -eq $sumNum) { $sumNum = 0.0 }
  $sumDen = ($den | Measure-Object -Sum).Sum; if ($null -eq $sumDen) { $sumDen = 0.0 }
  $windowRatio = if ($sumDen -gt 0) { [math]::Round([double]$sumNum / [double]$sumDen, 4) } else { $null }

  [pscustomobject]@{
    window_start_utc = $start
    window_end_utc   = $end
    service          = $Service
    last_minute      = [pscustomobject]@{ total = [double]$lastDen; errors_5xx = [double]$lastNum; ratio = $lastRatio }
    window           = [pscustomobject]@{ total = [double]$sumDen; errors_5xx = [double]$sumNum; ratio = $windowRatio }
  }
}

# ---------------- Monitoring channels & policies ----------------
function New-AndSend-MonEmailChannel {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Email,
    [string]$DisplayName = 'Ops email'
  )
  $name = gcloud alpha monitoring channels create `
    --display-name="$DisplayName" `
    --type=email `
    --channel-labels="email_address=$Email" `
    --format="value(name)"
  if (-not $name) { throw "Failed to create notification channel for $Email" }
  $access = gcloud auth print-access-token
  Invoke-RestMethod -Method POST `
    -Uri ("https://monitoring.googleapis.com/v3/{0}:sendVerificationCode" -f $name) `
    -Headers @{ Authorization = "Bearer $access"; "Content-Type"="application/json" } `
    -Body "{}" | Out-Null
  Write-Host "Created channel: $name`nVerification code sent to $Email."
  return $name
}

function Verify-MonEmailChannel {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ChannelName,
    [Parameter(Mandatory)][string]$Code
  )
  $access = gcloud auth print-access-token
  Invoke-RestMethod -Method POST `
    -Uri ("https://monitoring.googleapis.com/v3/{0}:verify" -f $ChannelName) `
    -Headers @{ Authorization = "Bearer $access"; "Content-Type"="application/json" } `
    -Body (@{ code=$Code } | ConvertTo-Json) | Out-Null
  Write-Host "Channel verified."
}

function Create-MonPolicies {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$ChannelId,
    [string]$Service = $script:CryptoOps.DefaultService
  )
  $Project = (gcloud config get-value core/project)
  $chanFull = "projects/$Project/notificationChannels/$ChannelId"

  $policy5 = @{
    displayName = "Cloud Run 5xx error rate > 5% ($Service)"
    enabled = $true
    conditions = @(@{
      displayName = "5xx ratio > 5% (5m)"
      conditionThreshold = @{
        filter  = "resource.type=""cloud_run_revision"" AND resource.labels.service_name=""$Service"" AND metric.type=""run.googleapis.com/request_count"" AND metric.labels.response_code_class=""5xx"""
        aggregations = @(@{ alignmentPeriod="60s"; perSeriesAligner="ALIGN_DELTA"; crossSeriesReducer="REDUCE_SUM" })
        denominatorFilter = "resource.type=""cloud_run_revision"" AND resource.labels.service_name=""$Service"" AND metric.type=""run.googleapis.com/request_count"""
        denominatorAggregations = @(@{ alignmentPeriod="60s"; perSeriesAligner="ALIGN_DELTA"; crossSeriesReducer="REDUCE_SUM" })
        comparison = "COMPARISON_GT"
        thresholdValue = 0.05
        duration = "300s"
        trigger = @{ count = 1 }
      }
    })
    documentation = @{ content = "5xx error rate exceeded 5% for 5 minutes on $Service."; mimeType="text/markdown" }
    notificationChannels = @($chanFull)
  }

  $policyLat = @{
    displayName = "Cloud Run p95 latency > 2s ($Service)"
    enabled = $true
    conditions = @(@{
      displayName = "p95 latency > 2s (5m)"
      conditionThreshold = @{
        filter  = "resource.type=""cloud_run_revision"" AND resource.labels.service_name=""$Service"" AND metric.type=""run.googleapis.com/request_latencies"""
        aggregations = @(@{ alignmentPeriod="60s"; perSeriesAligner="ALIGN_PERCENTILE_95"; crossSeriesReducer="REDUCE_MAX" })
        comparison = "COMPARISON_GT"
        thresholdValue = 2000
        duration = "300s"
        trigger = @{ count = 1 }
      }
    })
    documentation = @{ content = "p95 request latency exceeded 2s for 5 minutes on $Service."; mimeType="text/markdown" }
    notificationChannels = @($chanFull)
  }

  $tmp5  = Join-Path $env:TEMP "mon_5xx.json"
  $tmplat= Join-Path $env:TEMP "mon_p95.json"
  ($policy5  | ConvertTo-Json -Depth 32) | Set-Content -Path $tmp5  -Encoding UTF8
  ($policyLat| ConvertTo-Json -Depth 32) | Set-Content -Path $tmplat-Encoding UTF8
  gcloud alpha monitoring policies create --policy-from-file="$tmp5"  | Out-Host
  gcloud alpha monitoring policies create --policy-from-file="$tmplat"| Out-Host
}

function Show-Policies {
  [CmdletBinding()]
  param([string]$Project = (gcloud config get-value core/project))
  $all = gcloud alpha monitoring policies list --project=$Project --format=json 2>$null | ConvertFrom-Json
  if ($all) {
    $all | ForEach-Object {
      [pscustomobject]@{ id=($_.name -replace '^.*/',''); displayName=$_.displayName; enabled=$_.enabled }
    } | Sort-Object displayName | Format-Table -AutoSize
  } else {
    Write-Host "No alert policies found in project: $Project"
  }
}

function Get-PolicyIdByName {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$DisplayName,
    [string]$Project = (gcloud config get-value core/project)
  )
  $flt = 'displayName="{0}"' -f $DisplayName.Replace('"','\"')
  $json = gcloud alpha monitoring policies list --project=$Project --format=json --filter "$flt" 2>$null | ConvertFrom-Json
  if (-not $json) { Write-Warning "No alert policy found with displayName: $DisplayName"; return $null }
  return ($json[0].name -replace '^.*/','')
}

function Get-PolicyIdByLike {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory)][string]$Contains,
    [string]$Project = (gcloud config get-value core/project)
  )
  $all = gcloud alpha monitoring policies list --project=$Project --format=json 2>$null | ConvertFrom-Json
  if (-not $all) { return $null }
  $hits = $all | Where-Object { $_.displayName -like "*$Contains*" }
  if (-not $hits) { Write-Warning "No policies matching: *$Contains*"; return $null }
  return $hits | ForEach-Object {
    [pscustomobject]@{
      id          = ($_.name -replace '^.*/','')
      displayName = $_.displayName
      enabled     = $_.enabled
      name        = $_.name
    }
  }
}

# ---------------- Debug endpoint toggles ----------------
function Enable-DebugEndpoints {
  [CmdletBinding()]
  param([string]$Service = $script:CryptoOps.DefaultService, [string]$Region = $script:CryptoOps.DefaultRegion)
  gcloud run services update $Service --region $Region --update-env-vars ENABLE_DEBUG_ENDPOINTS=1 | Out-Host
}
function Disable-DebugEndpoints {
  [CmdletBinding()]
  param([string]$Service = $script:CryptoOps.DefaultService, [string]$Region = $script:CryptoOps.DefaultRegion)
  gcloud run services update $Service --region $Region --update-env-vars ENABLE_DEBUG_ENDPOINTS=0 | Out-Host
}

Write-Host "Loaded win\ops.ps1 helpers. Dot-source this file in each new PowerShell session:  . .\win\ops.ps1"

