from libs.logger import get_logger
log = get_logger("basis")
if __name__ == "__main__":
    log.info("Basis bot skeleton: local-only, no trading. (Add connectivity later.)")
