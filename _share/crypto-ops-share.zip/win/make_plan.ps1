Param()
$root = Split-Path $PSScriptRoot -Parent
$env:PYTHONPATH = $root
$script = Join-Path $root "apps\rebalancer\emit_plan.py"
try { py -3 $script } catch { python $script }
