Param()
notepad .\.env
