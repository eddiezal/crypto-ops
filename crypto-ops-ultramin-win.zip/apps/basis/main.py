import os
from libs.logger import get_logger
from libs.dotenv_min import load_dotenv
from libs.notion_client_min import post_run

load_dotenv()
log = get_logger("basis")

def main():
    if os.getenv("KILL_SWITCH","false").lower()=="true":
        msg = "Kill-switch engaged. Skipping."
        log.info(msg)
        post_run("Basis","No-Op",0.0,msg)
        return

    dry = os.getenv("BASIS_DRY_RUN","true").lower()=="true"
    # pretend we see 10% APR; threshold 8%
    edge_apr = 0.10
    min_edge = 0.08
    decision = "(Dry) Enter" if dry and edge_apr >= min_edge else "No-Op"
    msg = f"Basis est edge={edge_apr:.0%} >= {min_edge:.0%}? DRY={dry}"
    log.info(msg)
    post_run("Basis", decision, 0.0, msg)

if __name__ == "__main__":
    main()
