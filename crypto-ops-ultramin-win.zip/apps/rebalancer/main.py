import os, json
from libs.logger import get_logger
from libs.dotenv_min import load_dotenv
from libs.notion_client_min import post_run

load_dotenv()
log = get_logger("rebalancer")

def main():
    if os.getenv("KILL_SWITCH","false").lower()=="true":
        msg = "Kill-switch engaged. Skipping."
        log.info(msg)
        post_run("Rebalancer","No-Op",0.0,msg)
        return

    dry = os.getenv("REBALANCER_DRY_RUN","true").lower()=="true"
    force = os.getenv("FORCE_REBALANCE","false").lower()=="true"
    decision = "Rebalance" if force else "No-Op"
    if dry and decision=="Rebalance":
        # in dry-run, just log as (Dry) Enter
        decision = "(Dry) Enter"

    msg = f"Rebalancer running. DRY={dry}. FORCE_REBALANCE={force}. Targets=BTC/ETH 50/50."
    log.info(msg)
    post_run("Rebalancer", decision, 0.0, msg)

if __name__ == "__main__":
    main()
